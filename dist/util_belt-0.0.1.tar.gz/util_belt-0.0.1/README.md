## utility beil
This is a utility package for convenient and easy use
it contains different simple utility modules