## utility belg
This is a utility package for convenient and easy use.
It contains different utility functions.